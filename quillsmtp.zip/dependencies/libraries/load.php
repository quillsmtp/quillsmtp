<?php
/**
 * Includes libraries
 *
 * @package QuillSMTP
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/action-scheduler/action-scheduler.php';
