export type ConfigValue =
	| string
	| boolean
	| number
	| [  ]
	| Record< string, unknown >;
