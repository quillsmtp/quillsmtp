<?php
if ( ! defined( 'ABSPATH' ) ) exit;

require __DIR__ . '/build/vendor/scoper-autoload.php';
